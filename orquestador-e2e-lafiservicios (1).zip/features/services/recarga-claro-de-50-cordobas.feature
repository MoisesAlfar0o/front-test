# language: es
@services
Característica: Servicios > Recarga - Recarga Claro de 50 córdobas

  Como usuario con permisos en Servicios > Recarga
  Quiero recarga claro de 50 córdobas
  Para verificar que se visualiza saldo actualizado

  Escenario: Recarga Claro de 50 córdobas
    Dado que el usuario navega a la sección "Servicios > Recarga"
    Cuando Recarga Claro de 50 córdobas
    Entonces Se visualiza saldo actualizado
