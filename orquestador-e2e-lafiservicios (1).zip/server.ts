// Full-stack entry point for LAFISErvicios E2E Orchestrator
import './server/server.js';
