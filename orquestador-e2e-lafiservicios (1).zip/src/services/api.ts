import { FeatureItem, GuardrailIssue, Job, MetaInfo } from '../types';
import { INITIAL_FEATURES, INITIAL_GUARDRAILS, INITIAL_JOBS, INITIAL_META } from './mockData';

// In-memory state storage for full standalone operation & preview
class LocalStateStore {
  features: FeatureItem[] = [];
  jobs: Job[] = [];
  guards: GuardrailIssue[] = [];
  meta: MetaInfo;
  subscribers: Map<string, (data: { t: string; text?: string; status?: string; warnings?: GuardrailIssue[] }) => void> = new Map();

  constructor() {
    this.features = JSON.parse(localStorage.getItem('lafise_qa_features') || 'null') || INITIAL_FEATURES;
    this.jobs = JSON.parse(localStorage.getItem('lafise_qa_jobs') || 'null') || INITIAL_JOBS;
    this.guards = INITIAL_GUARDRAILS;
    this.meta = INITIAL_META;
    this.updateStats();
  }

  save() {
    try {
      localStorage.setItem('lafise_qa_features', JSON.stringify(this.features));
      localStorage.setItem('lafise_qa_jobs', JSON.stringify(this.jobs));
    } catch {
      // storage unavailable
    }
  }

  updateStats() {
    this.meta.stats = {
      totalFeatures: this.features.length,
      verified: this.features.filter((f) => f.status === 'VERIFIED').length,
      approved: this.features.filter((f) => f.status === 'APPROVED').length,
      pendingApproval: this.features.filter((f) => f.status === 'NOT_APPROVED').length,
      withDrift: this.features.filter((f) => f.status === 'IMPLEMENTATION_DRIFT').length,
    };
  }

  getFeature(id: string) {
    return this.features.find((f) => f.id === id);
  }

  updateFeature(id: string, content: string) {
    const f = this.getFeature(id);
    if (!f) throw new Error('Feature no encontrado');
    f.content = content;
    // Extract scenarios from content
    const scenarios: string[] = [];
    const lines = content.split('\n');
    for (const line of lines) {
      const match = line.match(/^\s*(?:Escenario|Scenario):\s*(.+)$/i);
      if (match) {
        scenarios.push(match[1].trim());
      }
    }
    f.scenarios = scenarios.length > 0 ? scenarios : f.scenarios;
    if (f.status === 'APPROVED' || f.status === 'VERIFIED') {
      f.status = 'CHANGED';
    }
    this.updateStats();
    this.save();
    return f;
  }

  approveFeature(id: string) {
    const f = this.getFeature(id);
    if (!f) throw new Error('Feature no encontrado');
    f.status = 'APPROVED';
    this.updateStats();
    this.save();
    return f;
  }

  createDraft(data: { area: string; where: string; what: string; expect: string }) {
    const slugId = `${data.area}/${data.what.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30)}.feature`;
    const title = `${data.what.charAt(0).toUpperCase() + data.what.slice(1)}`;
    const newFeature: FeatureItem = {
      id: slugId,
      title,
      area: data.area,
      status: 'NOT_APPROVED',
      fixme: false,
      tags: ['@smoke', `@${data.area}`],
      scenarios: [`Flujo principal: ${data.what}`],
      missingSteps: {
        count: 3,
        missing: [
          `Dado que navego a la sección "${data.where}"`,
          `Cuando ${data.what}`,
          `Entonces ${data.expect}`
        ]
      },
      content: `# language: es
@smoke @${data.area}
Característica: ${title}
  Como operador de LAFISErvicios
  Quiero acceder al flujo de ${data.where}
  Para ${data.expect}

  Antecedentes:
    Dado que el usuario tiene credenciales válidas en LAFISErvicios
    Y cuenta con permisos en el módulo "${data.where}"

  Escenario: Flujo principal: ${data.what}
    Dado que me encuentro en la pantalla "${data.where}"
    Cuando ${data.what}
    Entonces ${data.expect}
    Y se almacena registro de auditoría con ID de transacción`
    };

    this.features.unshift(newFeature);
    this.updateStats();
    this.save();
    return newFeature;
  }

  createJob(type: 'draft' | 'implement' | 'run', payload: Job['payload']) {
    const jobId = `job-${Math.floor(1000 + Math.random() * 9000)}`;
    const newJob: Job = {
      id: jobId,
      type,
      status: 'RUNNING',
      createdAt: new Date().toISOString(),
      payload,
      logs: []
    };
    this.jobs.unshift(newJob);
    this.save();

    // Start asynchronous simulation of logs and state completion
    this.simulateJobExecution(newJob);

    return newJob;
  }

  simulateJobExecution(job: Job) {
    const listener = this.subscribers.get(job.id);
    const send = (text: string, status?: Job['status']) => {
      job.logs = job.logs || [];
      job.logs.push(text);
      if (status) {
        job.status = status;
        if (status === 'DONE' || status === 'FAILED') {
          job.finishedAt = new Date().toISOString();
        }
      }
      this.save();
      if (listener) {
        listener({ t: 'log', text, status: job.status });
      }
    };

    if (job.type === 'run') {
      const feat = this.getFeature(job.payload.feature || '');
      const scenarioName = job.payload.scenario || 'Todos los escenarios';
      const steps = [
        `[PLAYWRIGHT v1.50] Iniciando ejecución de: ${job.payload.feature || 'Suite completa'}`,
        `[SETUP] Cargando sesión autenticada desde test-results/.auth/user.json ... ✓`,
        `[WORKER #1] Lanzando navegador Chromium en modo headless con viewport 1920x1080`,
        `[SCENARIO] "${scenarioName}"`,
        `[STEP 1/4] Dado que el operador accede al módulo correspondiente ... ✓ 310ms`,
        `[STEP 2/4] Cuando ejecuta la acción especificada en el escenario ... ✓ 680ms`,
        `[STEP 3/4] Y envía la solicitud al backend LAFISErvicios ... ✓ 820ms`,
        `[STEP 4/4] Entonces se valida la regla de negocio y respuesta HTTP 200 ... ✓ 440ms`,
        `[ASSERTION] expect(page.getByRole("status")).toHaveText("Operación exitosa") ... ✓`,
        `[SUCCESS] Escenario completado exitosamente sin fallos de auto-waiting (2.25s)`,
        `[PLAYWRIGHT] Reporte generado en test-results/html/index.html`
      ];

      steps.forEach((step, idx) => {
        setTimeout(() => {
          const isLast = idx === steps.length - 1;
          send(step, isLast ? 'DONE' : 'RUNNING');
          if (isLast && feat) {
            feat.status = 'VERIFIED';
            feat.lastRun = {
              status: 'PASSED',
              durationMs: 2250,
              timestamp: new Date().toISOString()
            };
            this.updateStats();
            this.save();
          }
        }, (idx + 1) * 350);
      });
    } else if (job.type === 'implement') {
      const feat = this.getFeature(job.payload.feature || '');
      const steps = [
        `[AGENT:${this.meta.agent}] Leyendo archivo de especificación BDD: ${job.payload.feature}`,
        `[AGENT:${this.meta.agent}] Identificando steps sin implementar en tests/steps/...`,
        `[AGENT:${this.meta.agent}] Creando locators semánticos y métodos Page Object...`,
        `[AGENT:${this.meta.agent}] Escribiendo step definitions Playwright con tipado estricto...`,
        `[GUARDRAIL] Ejecutando linter estático de calidad y seguridad bancaria...`,
        `[GUARDRAIL] ✓ Verificado: Sin uso de page.waitForTimeout()`,
        `[GUARDRAIL] ✓ Verificado: Sin selectores frágiles XPath`,
        `[GUARDRAIL] ✓ Verificado: Enmascaramiento de datos sensibles conforme a PCI-DSS`,
        `[SUCCESS] Steps implementados correctamente. Archivo tests/steps/${feat?.area || 'common'}.steps.ts actualizado.`
      ];

      steps.forEach((step, idx) => {
        setTimeout(() => {
          const isLast = idx === steps.length - 1;
          send(step, isLast ? 'DONE' : 'RUNNING');
          if (isLast && feat) {
            feat.missingSteps = { count: 0, missing: [] };
            this.save();
          }
        }, (idx + 1) * 400);
      });
    } else if (job.type === 'draft') {
      const steps = [
        `[AGENT:${this.meta.agent}] Recibiendo requisitos de negocio para área "${job.payload.area}"`,
        `[AGENT:${this.meta.agent}] Analizando directivas ADR 0002 y formato Gherkin estándar en español`,
        `[AGENT:${this.meta.agent}] Generando estructura de Feature, Antecedentes y Escenario principal...`,
        `[AGENT:${this.meta.agent}] Validando directiva de idioma '# language: es' en cabecera`,
        `[SUCCESS] Archivo .feature generado en borrador. Pendiente de revisión y aprobación humana.`
      ];

      steps.forEach((step, idx) => {
        setTimeout(() => {
          const isLast = idx === steps.length - 1;
          send(step, isLast ? 'DONE' : 'RUNNING');
        }, (idx + 1) * 300);
      });
    }
  }

  cancelJob(id: string) {
    const job = this.jobs.find((j) => j.id === id);
    if (job) {
      job.status = 'CANCELLED';
      job.finishedAt = new Date().toISOString();
      const listener = this.subscribers.get(id);
      if (listener) {
        listener({ t: 'log', text: '[INFO] Ejecución cancelada por el operador.', status: 'CANCELLED' });
      }
      this.save();
    }
  }

  getDiff(featureId?: string) {
    const feat = featureId ? this.getFeature(featureId) : this.features[0];
    if (!feat) return 'Sin cambios pendientes.';
    return `diff --git a/features/${feat.id} b/features/${feat.id}
--- a/features/${feat.id}
+++ b/features/${feat.id}
@@ -14,6 +14,8 @@ Característica: ${feat.title}
   Escenario: Validación de seguridad
-    Dado que el usuario accede sin token
-    Entonces el sistema muestra error
+    Dado que el operador inicia sesión con Token Digital
+    Y valida los permisos de segundo factor
+    Entonces la transacción es autorizada con código criptográfico`;
  }
}

export const localStore = new LocalStateStore();

// Universal API wrapper that checks network or seamlessly falls back to localStore
export async function api<T = any>(path: string, options: Omit<RequestInit, 'body'> & { body?: any } = {}): Promise<T> {
  const headers = {
    'Content-Type': 'application/json',
    'X-Orchestrator': '1',
    ...(options.headers || {}),
  };

  try {
    const res = await fetch('/api' + path, {
      ...options,
      headers,
      body: options.body ? JSON.stringify(options.body) : undefined,
    });

    if (res.ok) {
      return res.status === 204 ? ({} as T) : await res.json();
    }
    // If server responded with 404 or 500, check if we should fall back to local mock
    if (res.status === 404 || res.status === 502 || res.status === 503) {
      return handleLocalFallback<T>(path, options);
    }
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || res.statusText);
  } catch (err: any) {
    // If network fetch failed entirely (e.g. no backend server running on /api)
    return handleLocalFallback<T>(path, options);
  }
}

function handleLocalFallback<T>(path: string, options: Omit<RequestInit, 'body'> & { body?: any }): T {
  const url = new URL(path, 'http://localhost');
  const pathname = url.pathname;
  const method = (options.method || 'GET').toUpperCase();

  if (pathname === '/meta') {
    return localStore.meta as unknown as T;
  }
  if (pathname === '/features') {
    return localStore.features as unknown as T;
  }
  if (pathname === '/jobs') {
    return localStore.jobs as unknown as T;
  }
  if (pathname === '/guards') {
    return { issues: localStore.guards } as unknown as T;
  }
  if (pathname === '/diff') {
    return { text: localStore.getDiff() } as unknown as T;
  }
  if (pathname === '/feature') {
    if (method === 'GET') {
      const id = url.searchParams.get('id') || '';
      const f = localStore.getFeature(id);
      if (!f) throw new Error('Feature no encontrado');
      return f as unknown as T;
    }
    if (method === 'PUT') {
      const { id, content } = options.body || {};
      const f = localStore.updateFeature(id, content);
      return f as unknown as T;
    }
  }
  if (pathname === '/approve') {
    const { id } = options.body || {};
    const f = localStore.approveFeature(id);
    return f as unknown as T;
  }
  if (pathname === '/config') {
    const { agent } = options.body || {};
    localStore.meta.agent = agent;
    return { success: true, agent } as unknown as T;
  }
  if (pathname === '/jobs') {
    if (method === 'POST') {
      const { type, ...payload } = options.body || {};
      if (type === 'draft') {
        localStore.createDraft(payload);
      }
      const j = localStore.createJob(type, payload);
      return j as unknown as T;
    }
  }
  if (pathname.startsWith('/jobs/')) {
    const parts = pathname.split('/');
    const id = parts[2];
    if (pathname.endsWith('/log')) {
      const job = localStore.jobs.find((j) => j.id === id);
      return { text: (job?.logs || []).join('\n') } as unknown as T;
    }
    if (method === 'DELETE') {
      localStore.cancelJob(id);
      return { success: true } as unknown as T;
    }
  }

  return {} as T;
}

// Universal event stream subscriber that works with real SSE or simulated fallback
export function subscribeToJobStream(
  jobId: string,
  onEvent: (data: { t: string; text?: string; status?: string; warnings?: GuardrailIssue[] }) => void
): () => void {
  // Check if real EventSource can connect
  let es: EventSource | null = null;
  let useFallback = false;

  try {
    es = new EventSource(`/api/jobs/${jobId}/stream`);
    es.onmessage = (event) => {
      try {
        const parsed = JSON.parse(event.data);
        onEvent(parsed);
      } catch {
        // invalid json
      }
    };
    es.onerror = () => {
      es?.close();
      useFallback = true;
      localStore.subscribers.set(jobId, onEvent);
    };
  } catch {
    useFallback = true;
  }

  if (useFallback || !es) {
    localStore.subscribers.set(jobId, onEvent);
  }

  return () => {
    if (es) es.close();
    localStore.subscribers.delete(jobId);
  };
}
