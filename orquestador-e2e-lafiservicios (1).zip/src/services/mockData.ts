import { FeatureItem, GuardrailIssue, Job, MetaInfo } from '../types';

export const INITIAL_FEATURES: FeatureItem[] = [
  {
    id: 'services/pago-agua-enacal.feature',
    title: 'Pago de Servicio de Agua Potable ENACAL',
    area: 'services',
    status: 'VERIFIED',
    fixme: false,
    tags: ['@smoke', '@pagos', '@enacal'],
    scenarios: [
      'Búsqueda y consulta de saldo de NIS válido',
      'Pago exitoso debitando cuenta de ahorros en córdobas',
      'Rechazo por saldo insuficiente en cuenta seleccionada'
    ],
    missingSteps: {
      count: 0,
      missing: []
    },
    lastRun: {
      status: 'PASSED',
      durationMs: 4210,
      timestamp: new Date(Date.now() - 1000 * 60 * 25).toISOString()
    },
    content: `# language: es
@smoke @pagos @enacal
Característica: Pago de Servicio de Agua Potable ENACAL
  Como usuario del BackOffice de LAFISErvicios
  Quiero procesar pagos de facturas de agua potable
  Para mantener al día los servicios básicos de los clientes bancarios

  Antecedentes:
    Dado que el operador inicia sesión en "LAFISErvicios BackOffice"
    Y tiene permisos asignados para el módulo "Pago de Facturas y Servicios"

  Escenario: Búsqueda y consulta de saldo de NIS válido
    Dado que me encuentro en la pantalla "Servicios > Pagos > ENACAL"
    Cuando ingreso el NIS "829104" en el campo de búsqueda de suministro
    Y presiono el botón "Consultar Factura"
    Entonces el sistema muestra el nombre del abonado "DISTRIBUIDORA SAN JORGE S.A."
    Y visualizo un monto pendiente de "C$ 1,450.00" con fecha de corte vigente

  Escenario: Pago exitoso debitando cuenta de ahorros en córdobas
    Dado que tengo la factura del NIS "829104" en estado consultado
    Cuando selecciono la cuenta de origen "Cuenta Ahorro Córdobas ****4892"
    Y confirmo el pago presionando "Procesar Transacción"
    Entonces el sistema emite el comprobante digital con código de aprobación bancario
    Y el saldo del suministro pasa a estado "PAGADO" en el core bancario

  Escenario: Rechazo por saldo insuficiente en cuenta seleccionada
    Dado que consulto una factura con saldo adeudado de "C$ 3,200.00"
    Cuando elijo una cuenta que solo dispone de "C$ 500.00"
    Y presiono "Procesar Transacción"
    Entonces se visualiza la alerta "Saldo insuficiente para completar la operación"
    Y la transacción no genera débito en la cuenta del cliente`
  },
  {
    id: 'transfers/transferencia-ach-inmediata.feature',
    title: 'Transferencia Interbancaria ACH Inmediata',
    area: 'transfers',
    status: 'APPROVED',
    fixme: false,
    tags: ['@ach', '@inmediata', '@core'],
    scenarios: [
      'Transferencia hacia banco destino UniRed exitosa',
      'Validación de comisión bancaria para monto mayor a $1,000'
    ],
    missingSteps: {
      count: 2,
      missing: [
        'Dado que el límite diario de ACH no ha sido superado',
        'Y se calcula la tasa de cambio oficial BCN del día'
      ]
    },
    lastRun: {
      status: 'PASSED',
      durationMs: 6180,
      timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString()
    },
    content: `# language: es
@ach @inmediata @core
Característica: Transferencia Interbancaria ACH Inmediata
  Como cliente corporativo de LAFISErvicios
  Quiero transferir fondos a cuentas de otros bancos de la red
  Para liquidar pagos a proveedores en tiempo real

  Antecedentes:
    Dado que el usuario autenticado tiene cuenta corriente activa
    Y el límite diario de ACH no ha sido superado

  Escenario: Transferencia hacia banco destino UniRed exitosa
    Dado que estoy en la sección "Transferencias > A Otros Bancos (ACH)"
    Cuando selecciono el banco destino "Banco de la Producción (BANPRO)"
    Y escribo la cuenta beneficiario "001-203948-1002"
    Y especifico el monto "C$ 25,000.00" con concepto "Pago de Nómina"
    Y confirmo con mi Token Digital de segundo factor
    Entonces la transferencia se acredita en menos de 15 segundos
    Y se envía notificación por SMS y correo al ordenante

  Escenario: Validación de comisión bancaria para monto mayor a $1,000
    Dado que ingreso un monto de transferencia de "US$ 1,500.00"
    Y se calcula la tasa de cambio oficial BCN del día
    Cuando visualizo la pantalla de resumen previa a confirmar
    Entonces el desglose muestra la tarifa ACH de "US$ 2.50" más IVA
    Y el débito total estimado refleja el monto neto más comisiones`
  },
  {
    id: 'cards/bloqueo-preventivo-tarjeta.feature',
    title: 'Bloqueo Preventivo de Tarjeta de Débito',
    area: 'cards',
    status: 'IMPLEMENTATION_DRIFT',
    fixme: true,
    tags: ['@tarjetas', '@seguridad', '@fixme'],
    scenarios: [
      'Bloqueo temporal inmediato por sospecha de fraude',
      'Desbloqueo seguro mediante validación biométrica'
    ],
    missingSteps: {
      count: 1,
      missing: ['Y el estado en la pasarela Visa/MasterCard se actualiza a "HOT-CARD"']
    },
    lastRun: {
      status: 'FAILED',
      durationMs: 3890,
      timestamp: new Date(Date.now() - 1000 * 60 * 480).toISOString()
    },
    content: `# language: es
@tarjetas @seguridad @fixme
Característica: Bloqueo Preventivo de Tarjeta de Débito
  Como tarjetahabiente de LAFISErvicios
  Quiero bloquear preventivamente mi tarjeta en cualquier momento
  Para evitar transacciones no autorizadas por extravío o sospecha de clonación

  Escenario: Bloqueo temporal inmediato por sospecha de fraude
    Dado que tengo la tarjeta de débito Platinum activa "****8821"
    Cuando activo la opción "Bloqueo Preventivo" desde el BackOffice
    Y selecciono el motivo "Sospecha de clonación en cajero"
    Entonces el plástico queda suspendido inmediatamente para compras físicas y online
    Y el estado en la pasarela Visa/MasterCard se actualiza a "HOT-CARD"

  Escenario: Desbloqueo seguro mediante validación biométrica
    Dado que la tarjeta "****8821" se encuentra con bloqueo preventivo
    Cuando el oficial de servicio valida la identidad del titular
    Y confirma el código de seguridad OTP emitido a la app bancaria
    Entonces la tarjeta regresa al estado "ACTIVA - OPERATIVA"
    Y se registra bitácora de auditoría con ID del operador y timestamp`
  },
  {
    id: 'services/recarga-prepago-movil.feature',
    title: 'Recarga de Tiempo Aire y Paquetes de Datos',
    area: 'services',
    status: 'NOT_APPROVED',
    fixme: false,
    tags: ['@recargas', '@telecom'],
    scenarios: [
      'Recarga de saldo Claro con confirmación de operadora',
      'Compra de paquete de internet ilimitado Tigo'
    ],
    missingSteps: {
      count: 3,
      missing: [
        'Cuando elijo el operador de telefonía móvil',
        'Y selecciono el paquete "Superpack 5 Días"',
        'Entonces recibo confirmación por webservice en tiempo real'
      ]
    },
    content: `# language: es
@recargas @telecom
Característica: Recarga de Tiempo Aire y Paquetes de Datos
  Como cliente de LAFISErvicios
  Quiero adquirir paquetes y recargas telefónicas
  Para mantenerme comunicado sin intermediarios externos

  Escenario: Recarga de saldo Claro con confirmación de operadora
    Dado que navego al apartado "Servicios > Telefonía Móvil"
    Cuando elijo el operador de telefonía móvil "Claro Nicaragua"
    Y digito el número celular "8877-1122"
    Y selecciono el monto de recarga "C$ 100.00"
    Entonces el saldo se acredita inmediatamente al abonado
    Y recibo confirmación por webservice en tiempo real

  Escenario: Compra de paquete de internet ilimitado Tigo
    Dado que el número telefónico es "8455-9900" de "Tigo Nicaragua"
    Cuando selecciono el paquete "Superpack 5 Días"
    Y autorizo el débito de mi cuenta de moneda nacional
    Entonces la operadora emite el SMS con los megas asignados`
  },
  {
    id: 'accounts/apertura-cuenta-digital.feature',
    title: 'Apertura de Cuenta Digital y KYC Simplificado',
    area: 'accounts',
    status: 'CHANGED',
    fixme: false,
    tags: ['@onboarding', '@kyc', '@digital'],
    scenarios: [
      'Validación de cédula de identidad y foto frontal en padrón electoral',
      'Asignación inmediata de número de cuenta y contrato digital'
    ],
    missingSteps: {
      count: 0,
      missing: []
    },
    lastRun: {
      status: 'PASSED',
      durationMs: 5120,
      timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString()
    },
    content: `# language: es
@onboarding @kyc @digital
Característica: Apertura de Cuenta Digital y KYC Simplificado
  Como futuro cliente de Banco LAFISE
  Quiero abrir una cuenta de ahorro de forma remota
  Para empezar a operar sin necesidad de ir a sucursal física

  Escenario: Validación de cédula de identidad y foto frontal en padrón electoral
    Dado que el prospecto ingresa su número de identificación oficial
    Cuando sube la captura frontal y reversa del documento
    Y el motor de biometría facial verifica la prueba de vida
    Entonces el resultado del scoring de identidad resulta "APROBADO_CONFIABLE"

  Escenario: Asignación inmediata de número de cuenta y contrato digital
    Dado que el proceso de verificación KYC ha finalizado satisfactoriamente
    Cuando el usuario firma electrónicamente el contrato de adhesión
    Entonces el core bancario genera el número de cuenta de ahorro
    Y se envía la bienvenida con credenciales iniciales de LAFISErvicios`
  }
];

export const INITIAL_JOBS: Job[] = [
  {
    id: 'job-9821',
    type: 'run',
    status: 'DONE',
    createdAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
    finishedAt: new Date(Date.now() - 1000 * 60 * 24).toISOString(),
    payload: {
      feature: 'services/pago-agua-enacal.feature',
      scenario: 'Pago exitoso debitando cuenta de ahorros en córdobas'
    },
    logs: [
      '[PLAYWRIGHT] Running 1 scenario using Chromium engine in headless mode',
      '[STEP] Dado que el operador inicia sesión en "LAFISErvicios BackOffice" ... ✓ 420ms',
      '[STEP] Y tiene permisos asignados para el módulo "Pago de Facturas y Servicios" ... ✓ 180ms',
      '[STEP] Dado que tengo la factura del NIS "829104" en estado consultado ... ✓ 950ms',
      '[STEP] Cuando selecciono la cuenta de origen "Cuenta Ahorro Córdobas ****4892" ... ✓ 310ms',
      '[STEP] Y confirmo el pago presionando "Procesar Transacción" ... ✓ 1,120ms',
      '[STEP] Entonces el sistema emite el comprobante digital con código de aprobación bancario ... ✓ 680ms',
      '[STEP] Y el saldo del suministro pasa a estado "PAGADO" en el core bancario ... ✓ 550ms',
      '[SUCCESS] 1 passed (4.21s) - Report generated at test-results/html/index.html'
    ]
  },
  {
    id: 'job-9815',
    type: 'implement',
    status: 'DONE',
    createdAt: new Date(Date.now() - 1000 * 60 * 75).toISOString(),
    finishedAt: new Date(Date.now() - 1000 * 60 * 73).toISOString(),
    payload: {
      feature: 'services/pago-agua-enacal.feature'
    },
    logs: [
      '[AGENT:Claude] Analizando archivo BDD: features/services/pago-agua-enacal.feature',
      '[AGENT:Claude] Detectados 7 steps en español con prefijos BDD estándar',
      '[AGENT:Claude] Verificando steps existentes en tests/steps/services.steps.ts',
      '[AGENT:Claude] Generando step definitions con Playwright Page Object Model...',
      '[GUARDRAIL] Analizando código TypeScript generado según directivas ADR 0002...',
      '[GUARDRAIL] ✓ Sin llamadas prohibidas a waitForTimeout()',
      '[GUARDRAIL] ✓ Selectores usan locators semánticos getByRole() y getByTestId()',
      '[GUARDRAIL] ✓ Aserciones utilizan expect() web con auto-wait',
      '[SUCCESS] Archivo tests/steps/enacal.steps.ts creado exitosamente.'
    ]
  },
  {
    id: 'job-9804',
    type: 'run',
    status: 'FAILED',
    createdAt: new Date(Date.now() - 1000 * 60 * 480).toISOString(),
    finishedAt: new Date(Date.now() - 1000 * 60 * 478).toISOString(),
    payload: {
      feature: 'cards/bloqueo-preventivo-tarjeta.feature'
    },
    logs: [
      '[PLAYWRIGHT] Executing suite: cards/bloqueo-preventivo-tarjeta.feature',
      '[STEP] Dado que tengo la tarjeta de débito Platinum activa "****8821" ... ✓ 320ms',
      '[STEP] Cuando activo la opción "Bloqueo Preventivo" desde el BackOffice ... ✓ 640ms',
      '[STEP] Y selecciono el motivo "Sospecha de clonación en cajero" ... ✓ 280ms',
      '[STEP] Entonces el plástico queda suspendido inmediatamente ... ✓ 410ms',
      '[STEP] Y el estado en la pasarela Visa/MasterCard se actualiza a "HOT-CARD" ... ✕ 3,000ms',
      '[ERROR] TimeoutError: locator.waitFor({ state: "visible" }) exceeded 3000ms',
      '[ERROR] Step definition missing mock response for Visa API gateway webhook',
      '[FAILED] 1 failed, 1 skipped. Exit code 1.'
    ]
  }
];

export const INITIAL_GUARDRAILS: GuardrailIssue[] = [
  {
    level: 'CRITICAL',
    rule: 'no-wait-for-timeout',
    message: 'Se detectó uso de page.waitForTimeout(5000). Prohibido por ADR 0004 de LAFISErvicios.',
    file: 'tests/steps/cards.steps.ts',
    line: 42,
    snippet: 'await page.waitForTimeout(5000); // Esperar pasarela Visa',
    remedy: 'Reemplazar por expect(locator).toBeVisible({ timeout: 10000 }) con auto-waiting nativo de Playwright.'
  },
  {
    level: 'WARNING',
    rule: 'no-networkidle',
    message: 'Uso desaconsejado de waitForLoadState("networkidle") en aplicaciones con WebSockets activos.',
    file: 'tests/steps/transfers.steps.ts',
    line: 88,
    snippet: 'await page.waitForLoadState("networkidle");',
    remedy: 'Esperar específicamente la respuesta de la API ACH con page.waitForResponse("/api/ach/v1/transfer").'
  },
  {
    level: 'WARNING',
    rule: 'avoid-raw-xpath',
    message: 'Selector XPath detectado. Favorecer locators semánticos por rol o data-testid.',
    file: 'tests/steps/services.steps.ts',
    line: 114,
    snippet: 'await page.locator("//div[@class=\'receipt\']/button[2]").click();',
    remedy: 'Utilizar page.getByRole("button", { name: "Descargar Recibo" }) o getByTestId("btn-download-voucher").'
  }
];

export const INITIAL_META: MetaInfo = {
  app: 'Orquestador E2E LAFISErvicios BackOffice',
  version: '2.4.0',
  agent: 'claude',
  agentStatus: {
    available: true,
    warning: '',
    version: 'Claude Code CLI v1.2.8'
  },
  auth: {
    exists: true,
    user: 'qa.automation@lafise.com',
    expiresAt: '2026-10-28T18:00:00Z',
    path: 'test-results/.auth/user.json'
  },
  areas: ['services', 'transfers', 'cards', 'accounts', 'fx-exchange', 'loans'],
  stats: {
    totalFeatures: 5,
    verified: 1,
    approved: 1,
    pendingApproval: 1,
    withDrift: 1
  }
};
