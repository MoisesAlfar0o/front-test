import React from 'react';
import { Check, CircleDot, Clock } from 'lucide-react';
import { FeatureStatus } from '../types';

interface TrackStepperProps {
  status: FeatureStatus;
  hasSteps: boolean;
}

const STEPS = [
  {
    name: 'Borrador BDD',
    desc: 'Especificación Gherkin en español'
  },
  {
    name: 'Aprobado (ADR 0002)',
    desc: 'Revisión humana antes de automatizar'
  },
  {
    name: 'Steps Generados',
    desc: 'Locators y Page Objects implementados'
  },
  {
    name: 'Verificado E2E',
    desc: 'Prueba pasando en Playwright'
  }
];

export const TrackStepper: React.FC<TrackStepperProps> = ({ status, hasSteps }) => {
  const isApproved = status === 'APPROVED' || status === 'VERIFIED';
  const isStepsDone = isApproved && hasSteps;
  const isVerified = status === 'VERIFIED';

  // State array: [draftDone, approvedDone, stepsDone, verifiedDone]
  const doneStates = [true, isApproved, isStepsDone, isVerified];
  // Find current active step index
  const currentIndex = doneStates.lastIndexOf(true);
  const activeStep = currentIndex < 3 ? currentIndex + 1 : 3;

  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4 dark:border-slate-800 dark:bg-slate-900/60">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          Ciclo de Vida de Automatización
        </span>
        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
          Etapa {doneStates.filter(Boolean).length} de 4
        </span>
      </div>

      <ol className="relative grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mt-3">
        {STEPS.map((step, idx) => {
          const isDone = doneStates[idx];
          const isNow = idx === activeStep && !isVerified;

          return (
            <li key={step.name} className="relative flex flex-col">
              {/* Connector line for desktop */}
              {idx < STEPS.length - 1 && (
                <div
                  className={`hidden md:block absolute top-3.5 left-8 right-[-1rem] h-0.5 z-0 ${
                    doneStates[idx + 1]
                      ? 'bg-emerald-500 dark:bg-emerald-600'
                      : 'bg-slate-200 dark:bg-slate-800'
                  }`}
                  aria-hidden="true"
                />
              )}

              <div className="flex items-center gap-2 z-10">
                <div
                  className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 transition-colors ${
                    isDone
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : isNow
                      ? 'bg-white border-2 border-blue-600 text-blue-600 dark:bg-slate-900 dark:border-blue-400 dark:text-blue-400 ring-4 ring-blue-100 dark:ring-blue-950/80'
                      : 'bg-slate-100 border border-slate-300 text-slate-400 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-500'
                  }`}
                >
                  {isDone ? (
                    <Check className="h-3.5 w-3.5 stroke-[2.5]" />
                  ) : isNow ? (
                    <CircleDot className="h-3.5 w-3.5 animate-pulse" />
                  ) : (
                    <span>{idx + 1}</span>
                  )}
                </div>

                <div className="flex flex-col min-w-0">
                  <span
                    className={`text-xs font-semibold truncate ${
                      isDone
                        ? 'text-slate-900 dark:text-slate-100'
                        : isNow
                        ? 'text-blue-700 dark:text-blue-400'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {step.name}
                  </span>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 hidden sm:block truncate">
                    {step.desc}
                  </span>
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
};
