import React, { useState } from 'react';
import {
  Sparkles,
  Layers,
  ArrowRight,
  ShieldCheck,
  FileCode2,
  Check
} from 'lucide-react';

interface NewTestFormProps {
  areas: string[];
  busy: boolean;
  onSubmit: (data: { area: string; where: string; what: string; expect: string }) => void;
  onCancel: () => void;
}

const slug = (s: string) =>
  s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

const AREA_PRESETS = [
  { id: 'services', label: 'Servicios Públicos', desc: 'Agua, luz, telefonía y tributos' },
  { id: 'transfers', label: 'Transferencias ACH / UniRed', desc: 'Interbancarias e inmediatas' },
  { id: 'cards', label: 'Gestión de Tarjetas', desc: 'Límites, bloqueos y PIN' },
  { id: 'accounts', label: 'Cuentas & Onboarding', desc: 'Aperturas y consultas multimoneda' },
];

export const NewTestForm: React.FC<NewTestFormProps> = ({
  areas,
  busy,
  onSubmit,
  onCancel
}) => {
  const [formData, setFormData] = useState({
    area: areas.includes('services') ? 'services' : areas[0] || 'services',
    customArea: '',
    where: 'Servicios > Pagos > Recibos de Suministro',
    what: 'Busco NIS "829104" y selecciono pagar con Cuenta Corriente',
    expect: 'El sistema emite comprobante digital con código de aprobación bancario'
  });

  const isOther = formData.area === '__other';
  const effectiveArea = isOther ? slug(formData.customArea) : formData.area;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!effectiveArea) return;
    onSubmit({
      area: effectiveArea,
      where: formData.where,
      what: formData.what,
      expect: formData.expect
    });
  };

  // Dynamic preview of the generated Gherkin feature
  const previewGherkin = `# language: es
@smoke @${effectiveArea || 'area'}
Característica: ${formData.what ? formData.what.charAt(0).toUpperCase() + formData.what.slice(1) : 'Nueva prueba de negocio'}
  Como operador de LAFISErvicios BackOffice
  Quiero acceder al flujo de ${formData.where || '...'}
  Para validar ${formData.expect || '...'}

  Antecedentes:
    Dado que el operador inicia sesión en "LAFISErvicios BackOffice"
    Y cuenta con permisos asignados en el módulo "${formData.where || '...'}"

  Escenario: ${formData.what || 'Acción principal del usuario'}
    Dado que me encuentro en la pantalla "${formData.where || '...'}"
    Cuando ${formData.what || '...'}
    Entonces ${formData.expect || '...'}
    Y se registra en la bitácora de auditoría transaccional`;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
              <Sparkles className="h-4 w-4" />
            </span>
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Nueva Prueba E2E BDD con IA
            </h2>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Define la especificación en lenguaje de negocio cotidiano. El agente generará el archivo{' '}
            <code>.feature</code> en Gherkin en español según los estándares ADR 0002.
          </p>
        </div>

        <button
          onClick={onCancel}
          className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 underline self-start sm:self-auto"
        >
          Cancelar y volver
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Form Inputs (7 cols) */}
        <form onSubmit={handleSubmit} className="lg:col-span-7 space-y-4">
          {/* Functional Area Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Área Funcional (LAFISErvicios)
            </label>

            <div className="grid grid-cols-2 gap-2">
              {AREA_PRESETS.map((p) => {
                const active = formData.area === p.id;
                return (
                  <button
                    type="button"
                    key={p.id}
                    onClick={() => setFormData({ ...formData, area: p.id })}
                    className={`p-2.5 text-left rounded-lg border transition-all text-xs ${
                      active
                        ? 'border-blue-600 bg-blue-50/70 text-blue-950 dark:border-blue-400 dark:bg-blue-950/60 dark:text-blue-100 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="font-semibold flex items-center justify-between">
                      <span>{p.label}</span>
                      {active && <Check className="h-3 w-3 text-blue-600 dark:text-blue-400" />}
                    </div>
                    <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                      {p.desc}
                    </p>
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, area: '__other' })}
                className={`text-[11px] font-medium underline ${
                  isOther
                    ? 'text-blue-700 dark:text-blue-400 font-semibold'
                    : 'text-slate-500 hover:text-slate-800 dark:text-slate-400'
                }`}
              >
                + Ingresar otra área personalizada
              </button>
            </div>

            {isOther && (
              <div className="pt-1">
                <input
                  type="text"
                  value={formData.customArea}
                  onChange={(e) => setFormData({ ...formData, customArea: e.target.value })}
                  placeholder="ejemplo: prestamos-personales"
                  required
                  className="w-full rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                />
                <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                  Ruta destino: features/{effectiveArea || '...'}/
                </p>
              </div>
            )}
          </div>

          {/* Dónde */}
          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              1. Dónde (Pantalla o sección de LAFISErvicios)
            </label>
            <input
              type="text"
              value={formData.where}
              onChange={(e) => setFormData({ ...formData, where: e.target.value })}
              placeholder="Ej: Transferencias > A otros bancos (ACH)"
              required
              className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </div>

          {/* Qué hace */}
          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              2. Qué hace la persona (Acciones del usuario / Input de negocio)
            </label>
            <input
              type="text"
              value={formData.what}
              onChange={(e) => setFormData({ ...formData, what: e.target.value })}
              placeholder='Ej: Busco "ENACAL" y pago C$ 1,500.00 con Token Digital'
              required
              className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </div>

          {/* Qué debe pasar */}
          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              3. Qué debe pasar (Resultado esperado / Regla de negocio)
            </label>
            <textarea
              rows={3}
              value={formData.expect}
              onChange={(e) => setFormData({ ...formData, expect: e.target.value })}
              placeholder="Ej: La factura pasa a estado PAGADO y se descarga el comprobante oficial"
              required
              className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 resize-none"
            />
          </div>

          {/* ADR 0002 Note */}
          <div className="p-3 rounded-lg bg-blue-50/60 dark:bg-blue-950/40 border border-blue-200/60 dark:border-blue-900/40 text-[11px] text-blue-900 dark:text-blue-300 flex items-start gap-2">
            <ShieldCheck className="h-4 w-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Política ADR 0002 (Human-in-the-Loop):</span>
              <p className="mt-0.5 text-blue-800 dark:text-blue-300/90">
                El agente de IA solo creará el archivo <code>.feature</code> en borrador. No se implementará código de automatización ni se tocará el entorno hasta que revises y apruebes la especificación.
              </p>
            </div>
          </div>

          {/* Action */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={busy || !effectiveArea}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-md bg-blue-700 px-5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-blue-800 disabled:opacity-40 transition-colors"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>{busy ? 'Generando especificación con IA...' : 'Generar .feature con IA'}</span>
            </button>
          </div>
        </form>

        {/* Live Gherkin Preview (5 cols) */}
        <div className="lg:col-span-5 rounded-lg border border-slate-200 bg-slate-900 p-4 text-slate-200 space-y-2 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs text-slate-400 font-mono">
            <div className="flex items-center gap-1.5">
              <FileCode2 className="h-3.5 w-3.5 text-blue-400" />
              <span>Vista previa Gherkin en vivo</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-sans"># language: es</span>
          </div>

          <pre className="font-mono text-[11px] leading-relaxed text-slate-300 whitespace-pre-wrap overflow-x-auto max-h-[460px] py-1 select-text">
            {previewGherkin}
          </pre>
        </div>
      </div>
    </div>
  );
};
