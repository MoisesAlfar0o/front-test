import React from 'react';
import {
  X,
  CheckCircle2,
  AlertCircle,
  Clock,
  Laptop,
  Layers,
  ArrowRight,
  ExternalLink,
  Download
} from 'lucide-react';
import { FeatureItem } from '../types';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  features: FeatureItem[];
  selectedFeature: FeatureItem | null;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  features,
  selectedFeature
}) => {
  if (!isOpen) return null;

  const passedCount = features.filter((f) => f.lastRun?.status === 'PASSED').length;
  const failedCount = features.filter((f) => f.lastRun?.status === 'FAILED').length;
  const totalScenarios = features.reduce((acc, f) => acc + (f.scenarios?.length || 1), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="w-full max-w-4xl max-h-[90vh] flex flex-col rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="h-6 w-6 rounded bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
              PW
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <span>Reporte de Ejecución Playwright HTML</span>
                <span className="text-[11px] font-mono px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  v1.50
                </span>
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Resumen de validación E2E para LAFISErvicios BackOffice
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1 rounded text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Summary Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/60 dark:border-slate-800 dark:bg-slate-800/40">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                Total Escenarios
              </span>
              <div className="mt-1 text-xl font-bold font-mono text-slate-900 dark:text-slate-100 tabular-nums">
                {totalScenarios}
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-emerald-200 bg-emerald-50/60 dark:border-emerald-950/40 dark:bg-emerald-950/20">
              <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
                Pasando (Passed)
              </span>
              <div className="mt-1 text-xl font-bold font-mono text-emerald-700 dark:text-emerald-400 tabular-nums">
                {passedCount}
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-rose-200 bg-rose-50/60 dark:border-rose-950/40 dark:bg-rose-950/20">
              <span className="text-[11px] text-rose-700 dark:text-rose-400 font-medium">
                Fallidos (Failed)
              </span>
              <div className="mt-1 text-xl font-bold font-mono text-rose-700 dark:text-rose-400 tabular-nums">
                {failedCount}
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/60 dark:border-slate-800 dark:bg-slate-800/40">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                Navegador Motor
              </span>
              <div className="mt-1 text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <Laptop className="h-4 w-4 text-blue-600" />
                <span>Chromium 133</span>
              </div>
            </div>
          </div>

          {/* Test Suites Detail */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Desglose de Características
            </h4>

            <div className="space-y-2">
              {features.map((f) => {
                const isPassed = f.lastRun?.status === 'PASSED';
                const isFailed = f.lastRun?.status === 'FAILED';

                return (
                  <div
                    key={f.id}
                    className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-[200px]">
                      {isPassed ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                      ) : isFailed ? (
                        <AlertCircle className="h-4 w-4 text-rose-600 dark:text-rose-400 shrink-0" />
                      ) : (
                        <Clock className="h-4 w-4 text-slate-400 shrink-0" />
                      )}
                      <div>
                        <div className="font-semibold text-slate-900 dark:text-slate-100">
                          {f.title}
                        </div>
                        <div className="font-mono text-[11px] text-slate-500">
                          features/{f.id}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-[11px] text-slate-500">
                      <span>{f.scenarios?.length || 1} escenarios</span>
                      {f.lastRun ? (
                        <span className="font-mono tabular-nums">
                          {(f.lastRun.durationMs / 1000).toFixed(2)}s
                        </span>
                      ) : (
                        <span className="text-slate-400 italic">No ejecutado recientemente</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/80 text-xs">
          <span className="text-slate-500">
            Artefacto generado en <code>test-results/html/index.html</code>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 font-semibold"
          >
            Cerrar Reporte
          </button>
        </div>
      </div>
    </div>
  );
};
