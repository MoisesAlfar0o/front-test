import React from 'react';
import {
  Play,
  ShieldCheck,
  Moon,
  Sun,
  Bot,
  KeyRound,
  CheckCircle2,
  FileCheck2,
  AlertTriangle
} from 'lucide-react';
import { MetaInfo } from '../types';

interface TopBarProps {
  meta: MetaInfo | null;
  busy: boolean;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onChangeAgent: (agent: string) => void;
  onRunSuite: () => void;
  guardrailsCount: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  meta,
  busy,
  darkMode,
  onToggleDarkMode,
  onChangeAgent,
  onRunSuite,
  guardrailsCount
}) => {
  const isAuthOk = meta?.auth.exists ?? true;
  const currentAgent = meta?.agent || 'claude';

  return (
    <header className="h-14 border-b border-slate-200 bg-white px-4 md:px-6 dark:border-slate-800 dark:bg-slate-900 transition-colors flex items-center justify-between gap-4 z-30 shrink-0">
      {/* Zone 1: Brand & Context */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="flex items-center gap-2">
          <div className="h-7 w-7 rounded-md bg-blue-700 flex items-center justify-center text-white font-bold text-xs shadow-sm tracking-wider">
            LF
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold tracking-tight text-slate-900 dark:text-slate-100">
                LAFISErvicios
              </span>
              <span className="text-xs font-semibold text-blue-700 dark:text-blue-400">
                Orquestador E2E
              </span>
              <span className="hidden sm:inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-semibold bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                QA · BackOffice
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Zone 2: System Telemetry & Config */}
      <div className="hidden lg:flex items-center gap-4 text-xs">
        {/* Auth status */}
        <div
          className={`flex items-center gap-2 px-2.5 py-1 rounded-md border transition-colors ${
            isAuthOk
              ? 'border-emerald-200 bg-emerald-50/70 text-emerald-800 dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:text-emerald-300'
              : 'border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-900/60 dark:bg-amber-950/40 dark:text-amber-300'
          }`}
          title={
            isAuthOk
              ? `Sesión activa: ${meta?.auth.user || 'Usuario QA'} (test-results/.auth/)`
              : 'Sesión ausente: ejecuta pnpm auth:manual'
          }
        >
          <KeyRound className="h-3.5 w-3.5 shrink-0" />
          <span className="font-medium whitespace-nowrap">
            {isAuthOk ? 'Sesión QA Activa' : 'Sin Sesión (Requiere Auth)'}
          </span>
          <span
            className={`h-2 w-2 rounded-full ${
              isAuthOk ? 'bg-emerald-500 ring-2 ring-emerald-200 dark:ring-emerald-900' : 'bg-amber-500'
            }`}
          />
        </div>

        {/* AI Agent Selector */}
        <div className="flex items-center gap-2 px-2.5 py-1 rounded-md border border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-800 dark:bg-slate-800/80 dark:text-slate-200">
          <Bot className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400 shrink-0" />
          <span className="font-medium text-slate-500 dark:text-slate-400">Agente:</span>
          <select
            value={currentAgent}
            onChange={(e) => onChangeAgent(e.target.value)}
            className="bg-transparent font-semibold text-slate-900 dark:text-slate-100 text-xs focus:outline-none cursor-pointer"
            aria-label="Seleccionar motor de IA"
          >
            <option value="claude" className="dark:bg-slate-800">Claude Code CLI</option>
            <option value="cursor" className="dark:bg-slate-800">Cursor CLI</option>
            <option value="fake" className="dark:bg-slate-800">Motor Local (Pruebas)</option>
          </select>
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" title="Motor disponible" />
        </div>

        {/* Guardrails Status Indicator */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-800 dark:bg-slate-800/80 dark:text-slate-300">
          <ShieldCheck className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
          <span>ADR QA:</span>
          {guardrailsCount > 0 ? (
            <span className="font-semibold text-amber-600 dark:text-amber-400">
              {guardrailsCount} alertas
            </span>
          ) : (
            <span className="font-medium text-emerald-600 dark:text-emerald-400">
              Cumplimiento 100%
            </span>
          )}
        </div>
      </div>

      {/* Zone 3: Actions & Mode */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Dark mode toggle */}
        <button
          onClick={onToggleDarkMode}
          className="p-1.5 rounded-md border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-400 dark:hover:text-slate-100 dark:hover:bg-slate-800 transition-colors"
          title={darkMode ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro'}
          aria-label="Cambiar tema de color"
        >
          {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>

        {/* Global Run Action */}
        <button
          onClick={onRunSuite}
          disabled={busy}
          className="inline-flex items-center gap-2 rounded-md bg-blue-700 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-blue-800 active:bg-blue-900 disabled:opacity-50 transition-colors whitespace-nowrap"
        >
          <Play className="h-3.5 w-3.5 fill-current" />
          <span>{busy ? 'Ejecutando...' : 'Ejecutar Suite'}</span>
        </button>
      </div>
    </header>
  );
};
