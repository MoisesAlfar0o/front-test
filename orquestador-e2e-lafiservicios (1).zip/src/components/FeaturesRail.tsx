import React from 'react';
import {
  Plus,
  Search,
  CheckCircle2,
  AlertCircle,
  FileCode2,
  Clock,
  Sparkles,
  Layers,
  ChevronRight,
  Filter
} from 'lucide-react';
import { FeatureItem, FeatureStatus } from '../types';

interface FeaturesRailProps {
  features: FeatureItem[];
  selectedId: string | null;
  mode: 'feature' | 'new';
  onSelectFeature: (id: string) => void;
  onOpenNew: () => void;
  filterText: string;
  onFilterTextChange: (text: string) => void;
  filterStatus: string;
  onFilterStatusChange: (status: string) => void;
  selectedArea: string;
  onSelectArea: (area: string) => void;
  areas: string[];
  busy: boolean;
  onRunSuite: () => void;
}

const STATUS_CONFIG: Record<
  FeatureStatus,
  { label: string; textClass: string; bgClass: string; icon: React.ReactNode }
> = {
  VERIFIED: {
    label: 'Verificado',
    textClass: 'text-emerald-700 dark:text-emerald-400',
    bgClass: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/60',
    icon: <CheckCircle2 className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
  },
  APPROVED: {
    label: 'Aprobado',
    textClass: 'text-blue-700 dark:text-blue-400',
    bgClass: 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800/60',
    icon: <CheckCircle2 className="h-3 w-3 text-blue-600 dark:text-blue-400" />
  },
  CHANGED: {
    label: 'Editado',
    textClass: 'text-amber-700 dark:text-amber-400',
    bgClass: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800/60',
    icon: <AlertCircle className="h-3 w-3 text-amber-600 dark:text-amber-400" />
  },
  IMPLEMENTATION_DRIFT: {
    label: 'Deriva detectada',
    textClass: 'text-orange-700 dark:text-orange-400',
    bgClass: 'bg-orange-50 dark:bg-orange-950/40 border-orange-200 dark:border-orange-800/60',
    icon: <AlertCircle className="h-3 w-3 text-orange-600 dark:text-orange-400" />
  },
  NOT_APPROVED: {
    label: 'Sin aprobar',
    textClass: 'text-slate-600 dark:text-slate-400',
    bgClass: 'bg-slate-100 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700',
    icon: <Clock className="h-3 w-3 text-slate-500" />
  }
};

export const FeaturesRail: React.FC<FeaturesRailProps> = ({
  features,
  selectedId,
  mode,
  onSelectFeature,
  onOpenNew,
  filterText,
  onFilterTextChange,
  filterStatus,
  onFilterStatusChange,
  selectedArea,
  onSelectArea,
  areas,
  busy,
  onRunSuite
}) => {
  const filtered = features.filter((f) => {
    const area = f.area || f.id.split('/')[0] || '';
    const matchesText =
      !filterText ||
      f.id.toLowerCase().includes(filterText.toLowerCase()) ||
      (f.title && f.title.toLowerCase().includes(filterText.toLowerCase())) ||
      area.toLowerCase().includes(filterText.toLowerCase());

    const matchesStatus = filterStatus === 'ALL' || f.status === filterStatus;
    const matchesArea = selectedArea === 'ALL' || area === selectedArea;

    return matchesText && matchesStatus && matchesArea;
  });

  const verifiedCount = features.filter((f) => f.status === 'VERIFIED').length;
  const approvedCount = features.filter((f) => f.status === 'APPROVED').length;
  const pendingCount = features.filter((f) => f.status === 'NOT_APPROVED' || f.status === 'CHANGED').length;

  return (
    <aside className="w-full md:w-80 lg:w-[340px] flex flex-col border-r border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shrink-0 h-full overflow-hidden">
      {/* Header with New Test button */}
      <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 space-y-2.5 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            <Layers className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
            <span>Características E2E</span>
            <span className="font-mono text-[11px] text-slate-400 tabular-nums">
              ({features.length})
            </span>
          </div>

          <button
            onClick={onOpenNew}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              mode === 'new'
                ? 'bg-blue-700 text-white shadow-sm'
                : 'bg-blue-50 text-blue-700 hover:bg-blue-100 dark:bg-blue-950/60 dark:text-blue-300 dark:hover:bg-blue-900/60'
            }`}
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Nueva Prueba</span>
          </button>
        </div>

        {/* Search input */}
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
          <input
            type="search"
            value={filterText}
            onChange={(e) => onFilterTextChange(e.target.value)}
            placeholder="Buscar por nombre, ID o tag..."
            className="w-full rounded-md border border-slate-200 bg-slate-50 pl-8 pr-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-100 dark:focus:bg-slate-900 transition-colors"
          />
        </div>

        {/* Filter Bar: Status & Area */}
        <div className="flex items-center gap-2 pt-0.5">
          <select
            value={filterStatus}
            onChange={(e) => onFilterStatusChange(e.target.value)}
            className="flex-1 rounded border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 focus:outline-none cursor-pointer"
            aria-label="Filtrar por estado"
          >
            <option value="ALL">Todos los estados ({features.length})</option>
            <option value="VERIFIED">Verificados ({verifiedCount})</option>
            <option value="APPROVED">Aprobados ({approvedCount})</option>
            <option value="NOT_APPROVED">Sin aprobar</option>
            <option value="CHANGED">Editados tras aprobar</option>
            <option value="IMPLEMENTATION_DRIFT">Con deriva</option>
          </select>

          <select
            value={selectedArea}
            onChange={(e) => onSelectArea(e.target.value)}
            className="w-28 rounded border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 focus:outline-none cursor-pointer"
            aria-label="Filtrar por área funcional"
          >
            <option value="ALL">Áreas: Todas</option>
            {areas.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Feature list */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
        {filtered.length === 0 ? (
          <div className="py-12 px-4 text-center">
            <FileCode2 className="mx-auto h-8 w-8 text-slate-300 dark:text-slate-600 mb-2" />
            <p className="text-xs font-medium text-slate-600 dark:text-slate-400">
              No se encontraron features
            </p>
            <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
              Prueba cambiando los filtros de búsqueda o crea una nueva prueba.
            </p>
          </div>
        ) : (
          filtered.map((feature) => {
            const isSelected = selectedId === feature.id && mode === 'feature';
            const statusConfig = STATUS_CONFIG[feature.status] || STATUS_CONFIG.NOT_APPROVED;

            return (
              <button
                key={feature.id}
                onClick={() => onSelectFeature(feature.id)}
                className={`w-full text-left p-3 rounded-lg border transition-all ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/70 shadow-sm dark:border-blue-500 dark:bg-blue-950/40'
                    : 'border-slate-200/80 bg-white hover:border-slate-300 hover:bg-slate-50/80 dark:border-slate-800/80 dark:bg-slate-900/40 dark:hover:border-slate-700 dark:hover:bg-slate-800/40'
                }`}
              >
                {/* Title */}
                <div className="flex items-start justify-between gap-2">
                  <span
                    className={`text-xs font-semibold line-clamp-1 leading-snug ${
                      isSelected
                        ? 'text-blue-900 dark:text-blue-200'
                        : 'text-slate-900 dark:text-slate-100'
                    }`}
                  >
                    {feature.title}
                  </span>
                  {feature.fixme && (
                    <span className="text-[10px] font-mono px-1 rounded bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 shrink-0">
                      @fixme
                    </span>
                  )}
                </div>

                {/* Path identifier */}
                <p className="mt-1 font-mono text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  features/{feature.id}
                </p>

                {/* Metadata row with clean unboxed styling */}
                <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-1.5">
                    {statusConfig.icon}
                    <span className={`font-medium ${statusConfig.textClass}`}>
                      {statusConfig.label}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span>
                      {feature.scenarios
                        ? `${feature.scenarios.length} ${feature.scenarios.length === 1 ? 'escenario' : 'escenarios'}`
                        : feature.tags?.[0] || 'Gherkin'}
                    </span>
                    {feature.lastRun && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums text-slate-400">
                          {(feature.lastRun.durationMs / 1000).toFixed(1)}s
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>

      {/* Footer quick run */}
      <div className="p-3 border-t border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-900/90 shrink-0 flex items-center justify-between">
        <div className="text-[11px] text-slate-500 dark:text-slate-400">
          <span className="font-semibold text-slate-700 dark:text-slate-300">
            {verifiedCount}
          </span>{' '}
          de {features.length} verificados
        </div>
        <button
          onClick={onRunSuite}
          disabled={busy}
          className="text-xs font-semibold text-blue-700 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 disabled:opacity-50"
        >
          Ejecutar todos →
        </button>
      </div>
    </aside>
  );
};
