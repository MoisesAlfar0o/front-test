import React, { useState } from 'react';
import {
  FileCode,
  AlertTriangle,
  CheckCircle2,
  Copy,
  Check,
  Undo2,
  Sparkles,
  Eye,
  Edit3
} from 'lucide-react';
import { MissingSteps } from '../types';

interface GherkinEditorProps {
  value: string;
  savedValue: string;
  onChange: (val: string) => void;
  onAddLanguageHeader: () => void;
  missingSteps?: MissingSteps | null;
  status: string;
}

export const GherkinEditor: React.FC<GherkinEditorProps> = ({
  value,
  savedValue,
  onChange,
  onAddLanguageHeader,
  missingSteps,
  status
}) => {
  const [viewMode, setViewMode] = useState<'edit' | 'preview'>('edit');
  const [copied, setCopied] = useState(false);

  const hasLanguageEs = /^\s*#\s*language:\s*es/m.test(value);
  const isDirty = value !== savedValue;
  const noMissingSteps = missingSteps && missingSteps.count === 0;

  const handleCopy = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleInsertKeyword = (keyword: string) => {
    onChange(`${value}\n  ${keyword} `);
  };

  // Syntax highlighting for Gherkin in preview mode
  const renderHighlightedGherkin = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      const isComment = /^\s*#/.test(line);
      const isTag = /^\s*@/.test(line);
      const isFeature = /^\s*(?:Característica|Feature):/i.test(line);
      const isScenario = /^\s*(?:Escenario|Scenario|Antecedentes|Background|Regla|Rule):/i.test(line);
      const isStep = /^\s*(?:Dado|Cuando|Entonces|Y|Pero|Given|When|Then|And|But)\b/i.test(line);

      let lineClass = 'text-slate-800 dark:text-slate-200';
      if (isComment) lineClass = 'text-slate-400 dark:text-slate-500 italic';
      else if (isTag) lineClass = 'text-purple-600 dark:text-purple-400 font-semibold';
      else if (isFeature) lineClass = 'text-blue-700 dark:text-blue-400 font-bold';
      else if (isScenario) lineClass = 'text-amber-700 dark:text-amber-400 font-semibold';
      else if (isStep) lineClass = 'text-emerald-700 dark:text-emerald-300 font-medium';

      return (
        <div key={idx} className="flex hover:bg-slate-100/50 dark:hover:bg-slate-800/40">
          <span className="w-10 pr-3 text-right select-none text-[11px] font-mono text-slate-400 dark:text-slate-600 tabular-nums">
            {idx + 1}
          </span>
          <span className={`font-mono text-xs whitespace-pre-wrap ${lineClass}`}>
            {line || ' '}
          </span>
        </div>
      );
    });
  };

  return (
    <div className="flex flex-col gap-3 min-h-[360px] flex-1">
      {/* Missing steps banner */}
      {missingSteps && (
        <div
          className={`flex items-start justify-between gap-3 p-3 rounded-lg border text-xs transition-colors ${
            noMissingSteps
              ? 'border-emerald-200 bg-emerald-50/70 text-emerald-800 dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:text-emerald-300'
              : 'border-amber-200 bg-amber-50/80 text-amber-900 dark:border-amber-900/60 dark:bg-amber-950/40 dark:text-amber-200'
          }`}
        >
          <div className="flex items-start gap-2">
            {noMissingSteps ? (
              <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            )}
            <div>
              {noMissingSteps ? (
                <span className="font-medium">
                  Todos los pasos están implementados en <code>steps/</code>. Listo para ejecutar.
                </span>
              ) : (
                <>
                  <span className="font-semibold">
                    Faltan {missingSteps.count} paso(s) por implementar en los step definitions:
                  </span>
                  <ul className="mt-1 list-disc list-inside space-y-0.5 font-mono text-[11px] opacity-90">
                    {missingSteps.missing.slice(0, 3).map((m, i) => (
                      <li key={i}>{m}</li>
                    ))}
                    {missingSteps.missing.length > 3 && (
                      <li>...y {missingSteps.missing.length - 3} más</li>
                    )}
                  </ul>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Language Header Warning */}
      {!hasLanguageEs && (
        <div className="flex items-center justify-between gap-3 p-2.5 rounded-lg border border-amber-200 bg-amber-50 text-amber-900 dark:border-amber-900/60 dark:bg-amber-950/40 dark:text-amber-300 text-xs">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
            <span>
              Falta la directiva <code># language: es</code> en la cabecera para parser Gherkin en español.
            </span>
          </div>
          <button
            onClick={onAddLanguageHeader}
            className="px-2.5 py-1 text-[11px] font-semibold bg-amber-200/80 hover:bg-amber-300 dark:bg-amber-900 dark:hover:bg-amber-800 text-amber-950 dark:text-amber-100 rounded transition-colors shrink-0"
          >
            Insertar encabezado
          </button>
        </div>
      )}

      {/* Implementation Drift Warning */}
      {status === 'IMPLEMENTATION_DRIFT' && (
        <div className="flex items-start gap-2 p-2.5 rounded-lg border border-orange-200 bg-orange-50 text-orange-900 dark:border-orange-900/60 dark:bg-orange-950/40 dark:text-orange-300 text-xs">
          <AlertTriangle className="h-4 w-4 text-orange-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold">Deriva de implementación detectada (Drift):</span>
            <p className="mt-0.5 text-[11px] opacity-90">
              El código de los step definitions cambió desde la última aprobación. Revisa los cambios con el botón &quot;Ver cambios (Git)&quot; y vuelve a aprobar.
            </p>
          </div>
        </div>
      )}

      {/* Editor Box */}
      <div className="flex-1 flex flex-col rounded-lg border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-sm overflow-hidden">
        {/* Editor Toolbar */}
        <div className="flex items-center justify-between px-3.5 py-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 text-xs">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <FileCode className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
              <span>Editor Gherkin (.feature)</span>
            </span>
            {isDirty ? (
              <span className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-600 dark:text-amber-400">
                <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse" />
                Cambios sin guardar
              </span>
            ) : (
              <span className="text-[11px] text-slate-400">Guardado</span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Gherkin Snippets */}
            <div className="hidden sm:flex items-center gap-1 text-[11px]">
              <span className="text-slate-400 mr-1">Insertar:</span>
              {['Dado', 'Cuando', 'Entonces', 'Y'].map((kw) => (
                <button
                  key={kw}
                  onClick={() => handleInsertKeyword(kw)}
                  className="px-1.5 py-0.5 rounded bg-slate-200/70 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 font-mono text-[10px]"
                >
                  +{kw}
                </button>
              ))}
            </div>

            <span className="hidden sm:block h-3.5 w-px bg-slate-200 dark:bg-slate-800" />

            {/* View toggle */}
            <div className="flex items-center bg-slate-200/70 dark:bg-slate-800 p-0.5 rounded text-[11px]">
              <button
                onClick={() => setViewMode('edit')}
                className={`px-2 py-0.5 rounded font-medium flex items-center gap-1 ${
                  viewMode === 'edit'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                <Edit3 className="h-3 w-3" />
                <span>Editar</span>
              </button>
              <button
                onClick={() => setViewMode('preview')}
                className={`px-2 py-0.5 rounded font-medium flex items-center gap-1 ${
                  viewMode === 'preview'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                <Eye className="h-3 w-3" />
                <span>Vista Previa</span>
              </button>
            </div>

            {/* Copy button */}
            <button
              onClick={handleCopy}
              className="p-1 rounded text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
              title="Copiar contenido"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
            </button>
          </div>
        </div>

        {/* Editor Area */}
        <div className="flex-1 min-h-[280px] p-3 overflow-auto font-mono text-xs">
          {viewMode === 'preview' ? (
            <div className="space-y-0.5 py-1">{renderHighlightedGherkin(value)}</div>
          ) : (
            <textarea
              value={value}
              onChange={(e) => onChange(e.target.value)}
              spellCheck={false}
              className="w-full h-full min-h-[280px] bg-transparent text-slate-900 dark:text-slate-100 font-mono text-xs leading-relaxed focus:outline-none resize-none"
              placeholder="# Escribe aquí el archivo .feature en español..."
            />
          )}
        </div>
      </div>
    </div>
  );
};
