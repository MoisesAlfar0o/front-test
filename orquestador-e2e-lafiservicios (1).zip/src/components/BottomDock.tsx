import React, { useState, useRef, useLayoutEffect } from 'react';
import {
  Terminal,
  History,
  ShieldAlert,
  GitCompare,
  ArrowDown,
  Trash2,
  Download,
  RotateCw,
  XCircle,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { GuardrailIssue, Job, JobStatus } from '../types';

interface BottomDockProps {
  dockTab: 'consola' | 'historial' | 'guards' | 'diff';
  onTabChange: (tab: 'consola' | 'historial' | 'guards' | 'diff') => void;
  lines: string[];
  onClearLogs: () => void;
  job: { id: string; status: JobStatus } | null;
  busy: boolean;
  onCancelJob: () => void;
  history: Job[];
  guards: GuardrailIssue[];
  diffText: string;
  mineOnly: boolean;
  onToggleMineOnly: (val: boolean) => void;
  selectedFeatureId: string | null;
  onWatchJob: (id: string, status?: JobStatus) => void;
  onRepeatJob: (type: Job['type'], payload: Job['payload']) => void;
}

const JOB_STATUS_MAP: Record<JobStatus, { label: string; color: string }> = {
  QUEUED: { label: 'En cola', color: 'bg-slate-500 text-white' },
  RUNNING: { label: 'En ejecución', color: 'bg-blue-600 text-white animate-pulse' },
  DONE: { label: 'Terminado', color: 'bg-emerald-600 text-white' },
  FAILED: { label: 'Falló', color: 'bg-rose-600 text-white' },
  CANCELLED: { label: 'Cancelado', color: 'bg-slate-600 text-white' },
  AUTH_REQUIRED: { label: 'Requiere sesión', color: 'bg-amber-600 text-white' }
};

export const BottomDock: React.FC<BottomDockProps> = ({
  dockTab,
  onTabChange,
  lines,
  onClearLogs,
  job,
  busy,
  onCancelJob,
  history,
  guards,
  diffText,
  mineOnly,
  onToggleMineOnly,
  selectedFeatureId,
  onWatchJob,
  onRepeatJob
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const consoleRef = useRef<HTMLDivElement>(null);
  const stickRef = useRef(true);
  const [atEnd, setAtEnd] = useState(true);
  const [logFilter, setLogFilter] = useState('');

  const onScroll = () => {
    const el = consoleRef.current;
    if (!el) return;
    stickRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
    setAtEnd(stickRef.current);
  };

  useLayoutEffect(() => {
    if (stickRef.current && consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
    }
  }, [lines]);

  const jumpToEnd = () => {
    stickRef.current = true;
    if (consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
      setAtEnd(true);
    }
  };

  const handleDownloadLogs = () => {
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `qa-orchestrator-${job?.id || 'logs'}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredLines = logFilter
    ? lines.filter((l) => l.toLowerCase().includes(logFilter.toLowerCase()))
    : lines;

  return (
    <footer
      className={`border-t border-slate-200 dark:border-slate-800 bg-slate-900 text-slate-200 flex flex-col shrink-0 transition-all duration-200 ${
        isExpanded ? 'h-[460px]' : 'h-64 md:h-72'
      }`}
    >
      {/* Dock Tabs Header */}
      <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950 px-4 py-1.5 text-xs select-none">
        <div className="flex items-center gap-1">
          {/* Console Tab */}
          <button
            onClick={() => onTabChange('consola')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
              dockTab === 'consola'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Terminal className="h-3.5 w-3.5 text-blue-400" />
            <span>Consola de Ejecución</span>
            {job && (
              <span
                className={`ml-1 px-1.5 py-0.2 rounded text-[10px] font-semibold ${
                  JOB_STATUS_MAP[job.status]?.color || 'bg-slate-700'
                }`}
              >
                {JOB_STATUS_MAP[job.status]?.label || job.status}
              </span>
            )}
          </button>

          {/* History Tab */}
          <button
            onClick={() => onTabChange('historial')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
              dockTab === 'historial'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <History className="h-3.5 w-3.5 text-purple-400" />
            <span>Historial</span>
            <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 tabular-nums">
              {history.length}
            </span>
          </button>

          {/* Guardrails Tab */}
          <button
            onClick={() => onTabChange('guards')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
              dockTab === 'guards'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <ShieldAlert className="h-3.5 w-3.5 text-amber-400" />
            <span>Guardrails ADR</span>
            {guards.length > 0 && (
              <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-amber-950 text-amber-300 border border-amber-800/60">
                {guards.length}
              </span>
            )}
          </button>

          {/* Git Diff Tab */}
          <button
            onClick={() => onTabChange('diff')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
              dockTab === 'diff'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <GitCompare className="h-3.5 w-3.5 text-emerald-400" />
            <span>Git Diff</span>
          </button>
        </div>

        {/* Tab Controls & Right Tools */}
        <div className="flex items-center gap-2">
          {busy && (
            <button
              onClick={onCancelJob}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold rounded bg-rose-950 text-rose-300 border border-rose-800/80 hover:bg-rose-900 transition-colors"
            >
              <XCircle className="h-3 w-3" />
              <span>Cancelar tarea</span>
            </button>
          )}

          {/* Expand/Collapse dock */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            title={isExpanded ? 'Contraer panel' : 'Expandir panel'}
          >
            {isExpanded ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
          </button>
        </div>
      </div>

      {/* Dock Content Body */}
      <div className="flex-1 min-h-0 relative flex flex-col bg-slate-950">
        {dockTab === 'consola' ? (
          <div className="flex-1 flex flex-col min-h-0 relative">
            {/* Console Toolbar */}
            <div className="flex items-center justify-between px-4 py-1.5 border-b border-slate-900 bg-slate-950/90 text-xs">
              <div className="flex items-center gap-3">
                <span className="text-[11px] text-slate-400 font-mono">
                  {filteredLines.length} líneas
                </span>
                <input
                  type="text"
                  value={logFilter}
                  onChange={(e) => setLogFilter(e.target.value)}
                  placeholder="Filtrar logs..."
                  className="rounded bg-slate-900 border border-slate-800 px-2 py-0.5 text-[11px] text-slate-200 placeholder:text-slate-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={onClearLogs}
                  className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] text-slate-400 hover:text-slate-200 hover:bg-slate-900 rounded"
                  title="Limpiar consola"
                >
                  <Trash2 className="h-3 w-3" />
                  <span>Limpiar</span>
                </button>
                <button
                  onClick={handleDownloadLogs}
                  className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] text-slate-400 hover:text-slate-200 hover:bg-slate-900 rounded"
                  title="Descargar registro completo"
                >
                  <Download className="h-3 w-3" />
                  <span>Descargar</span>
                </button>
              </div>
            </div>

            {/* Scrollable Output */}
            <div
              ref={consoleRef}
              onScroll={onScroll}
              className="flex-1 p-3.5 overflow-y-auto font-mono text-xs leading-relaxed space-y-1 select-text"
            >
              {filteredLines.length === 0 ? (
                <div className="text-slate-500 py-6 text-center italic font-sans text-xs">
                  Aquí aparecerá la actividad de Playwright, generación de steps con IA y ejecución de pruebas.
                </div>
              ) : (
                filteredLines.map((line, idx) => {
                  let color = 'text-slate-300';
                  if (line.includes('✓') || line.includes('[SUCCESS]')) {
                    color = 'text-emerald-400 font-medium';
                  } else if (line.includes('✕') || line.includes('[ERROR]') || line.includes('[FAILED]')) {
                    color = 'text-rose-400 font-semibold';
                  } else if (line.includes('[AGENT:')) {
                    color = 'text-purple-300';
                  } else if (line.includes('[GUARDRAIL]')) {
                    color = 'text-amber-300';
                  } else if (line.includes('[STEP]')) {
                    color = 'text-blue-300';
                  }

                  return (
                    <div key={idx} className={`${color} break-all hover:bg-slate-900/50 px-1 rounded`}>
                      {line}
                    </div>
                  );
                })
              )}
            </div>

            {/* Jump to bottom button */}
            {!atEnd && (
              <button
                onClick={jumpToEnd}
                className="absolute right-4 bottom-3 z-20 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-lg transition-transform hover:scale-105"
              >
                <ArrowDown className="h-3.5 w-3.5" />
                <span>Ir al final</span>
              </button>
            )}
          </div>
        ) : dockTab === 'historial' ? (
          <div className="flex-1 p-4 overflow-y-auto space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400 pb-1 border-b border-slate-900">
              <span className="font-semibold text-slate-300">
                Historial de Ejecuciones ({history.length})
              </span>
              {selectedFeatureId && (
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={mineOnly}
                    onChange={(e) => onToggleMineOnly(e.target.checked)}
                    className="rounded border-slate-800 bg-slate-900 text-blue-600"
                  />
                  <span>Solo este feature ({selectedFeatureId})</span>
                </label>
              )}
            </div>

            {history.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">
                Sin ejecuciones registradas para los filtros seleccionados.
              </p>
            ) : (
              <div className="grid gap-2">
                {history.map((j) => (
                  <div
                    key={j.id}
                    className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg border border-slate-900 bg-slate-900/70 hover:bg-slate-900 transition-colors text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold tracking-wide ${
                          JOB_STATUS_MAP[j.status]?.color || 'bg-slate-700'
                        }`}
                      >
                        {JOB_STATUS_MAP[j.status]?.label || j.status}
                      </span>
                      <div className="flex flex-col">
                        <span className="font-semibold text-slate-200">
                          {j.type === 'run'
                            ? 'Ejecución Playwright'
                            : j.type === 'implement'
                            ? 'Generación de Steps IA'
                            : 'Borrador Feature'}
                        </span>
                        <span className="font-mono text-[11px] text-slate-400">
                          {j.payload?.scenario || j.payload?.feature || 'Suite completa'}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 text-[11px] text-slate-400">
                      <time>{new Date(j.createdAt).toLocaleTimeString()}</time>
                      <button
                        onClick={() => onWatchJob(j.id, j.status)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium"
                      >
                        Ver log
                      </button>
                      {j.type !== 'draft' && (
                        <button
                          onClick={() => onRepeatJob(j.type, j.payload)}
                          disabled={busy}
                          className="px-2.5 py-1 rounded bg-blue-900/60 hover:bg-blue-800 text-blue-200 font-medium flex items-center gap-1 disabled:opacity-40"
                        >
                          <RotateCw className="h-3 w-3" />
                          <span>Repetir</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : dockTab === 'guards' ? (
          <div className="flex-1 p-4 overflow-y-auto space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-slate-900">
              <span className="text-xs font-semibold text-slate-300">
                Auditoría de Buenas Prácticas BDD / Playwright (ADR QA LAFISE)
              </span>
              <span className="text-[11px] text-slate-500">
                Previene flaky tests, sleeps ciegos y dependencias de UI frágiles
              </span>
            </div>

            {guards.length === 0 ? (
              <div className="py-8 text-center">
                <CheckCircle2 className="mx-auto h-7 w-7 text-emerald-400 mb-2" />
                <p className="text-xs font-semibold text-emerald-300">
                  Cumplimiento 100% de los estándares de automatización
                </p>
                <p className="text-[11px] text-slate-500 mt-1">
                  No se detectaron `waitForTimeout()`, `networkidle` ni selectores XPath frágiles.
                </p>
              </div>
            ) : (
              <div className="grid gap-2.5">
                {guards.map((g, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-lg border border-amber-900/60 bg-amber-950/20 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            g.level === 'CRITICAL'
                              ? 'bg-rose-950 text-rose-300 border border-rose-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}
                        >
                          {g.level}
                        </span>
                        <span className="font-semibold text-slate-200">Regla: {g.rule}</span>
                      </div>
                      <span className="font-mono text-[11px] text-slate-400">
                        {g.file}:{g.line}
                      </span>
                    </div>

                    <p className="text-slate-300 text-[11px]">{g.message}</p>

                    {g.snippet && (
                      <pre className="p-2 rounded bg-slate-900 font-mono text-[11px] text-rose-300 overflow-x-auto">
                        {g.snippet}
                      </pre>
                    )}

                    {g.remedy && (
                      <div className="text-[11px] text-emerald-300 font-medium">
                        Solución recomendada: {g.remedy}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="flex-1 p-4 overflow-y-auto">
            <pre className="p-4 rounded-lg bg-slate-900 border border-slate-800 font-mono text-xs text-slate-300 whitespace-pre-wrap leading-relaxed">
              {diffText || 'Sin diferencias detectadas entre el archivo y el último commit de Git.'}
            </pre>
          </div>
        )}
      </div>
    </footer>
  );
};
