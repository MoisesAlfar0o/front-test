import React from 'react';
import {
  Save,
  CheckCircle,
  Sparkles,
  Play,
  GitCompare,
  ExternalLink,
  Loader2
} from 'lucide-react';

interface ActionsBarProps {
  dirty: boolean;
  ready: boolean;
  busy: boolean;
  noMissingSteps: boolean;
  scenarios: string[];
  targetScenario: string;
  onTargetScenarioChange: (val: string) => void;
  onSave: () => void;
  onApprove: () => void;
  onImplementSteps: () => void;
  onRunTest: () => void;
  onShowDiff: () => void;
  onOpenReport: () => void;
}

export const ActionsBar: React.FC<ActionsBarProps> = ({
  dirty,
  ready,
  busy,
  noMissingSteps,
  scenarios,
  targetScenario,
  onTargetScenarioChange,
  onSave,
  onApprove,
  onImplementSteps,
  onRunTest,
  onShowDiff,
  onOpenReport
}) => {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs">
      {/* Primary Workflow Group */}
      <div className="flex flex-wrap items-center gap-2">
        {/* Save button */}
        <button
          onClick={onSave}
          disabled={!dirty}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
        >
          <Save className="h-3.5 w-3.5" />
          <span>Guardar</span>
        </button>

        {/* Approve button (ADR 0002) */}
        <button
          onClick={onApprove}
          disabled={dirty || ready}
          title={
            dirty
              ? 'Guarda los cambios antes de aprobar'
              : ready
              ? 'El feature ya está aprobado'
              : 'Aprobar feature (ADR 0002: Human-in-the-loop)'
          }
          className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
            ready
              ? 'bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500 cursor-not-allowed'
              : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs disabled:opacity-40'
          }`}
        >
          <CheckCircle className="h-3.5 w-3.5" />
          <span>{ready ? 'Aprobado ✓' : 'Aprobar (ADR 0002)'}</span>
        </button>

        <span className="hidden sm:block h-4 w-px bg-slate-200 dark:bg-slate-800 mx-1" />

        {/* Implement Steps with AI button */}
        <button
          onClick={onImplementSteps}
          disabled={!ready || busy || noMissingSteps}
          title={
            !ready
              ? 'Debes aprobar el feature antes de generar código'
              : noMissingSteps
              ? 'Todos los steps ya están implementados'
              : 'El agente de IA generará los step definitions en TypeScript/Playwright'
          }
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border transition-colors whitespace-nowrap shrink-0 ${
            noMissingSteps
              ? 'border-slate-200 bg-slate-50 text-slate-400 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-600'
              : 'border-purple-200 bg-purple-50 text-purple-700 hover:bg-purple-100 dark:border-purple-900/60 dark:bg-purple-950/40 dark:text-purple-300 dark:hover:bg-purple-900/50 disabled:opacity-40'
          }`}
        >
          <Sparkles className="h-3.5 w-3.5 text-purple-600 dark:text-purple-400" />
          <span>
            {noMissingSteps ? 'Steps Completados' : 'Generar steps con IA'}
          </span>
        </button>
      </div>

      {/* Execution & Inspection Group */}
      <div className="flex flex-wrap items-center gap-2">
        {/* Scenario selector */}
        <div className="relative">
          <select
            value={targetScenario}
            onChange={(e) => onTargetScenarioChange(e.target.value)}
            disabled={!ready || busy}
            className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 max-w-[200px] truncate focus:outline-none cursor-pointer disabled:opacity-40"
            aria-label="Seleccionar escenario a ejecutar"
          >
            <option value="">Todo el feature ({scenarios.length} esc.)</option>
            {scenarios.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        {/* Execute button */}
        <button
          onClick={onRunTest}
          disabled={!ready || busy}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-md bg-blue-700 hover:bg-blue-800 text-white shadow-xs disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
        >
          {busy ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <Play className="h-3.5 w-3.5 fill-current" />
          )}
          <span>{busy ? 'Ejecutando...' : 'Ejecutar'}</span>
        </button>

        <span className="hidden sm:block h-4 w-px bg-slate-200 dark:bg-slate-800 mx-1" />

        {/* Diff button */}
        <button
          onClick={onShowDiff}
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-md border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0"
        >
          <GitCompare className="h-3.5 w-3.5" />
          <span>Ver Git Diff</span>
        </button>

        {/* HTML Report button */}
        <button
          onClick={onOpenReport}
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-md border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0"
        >
          <ExternalLink className="h-3.5 w-3.5" />
          <span>Reporte HTML</span>
        </button>
      </div>
    </div>
  );
};
