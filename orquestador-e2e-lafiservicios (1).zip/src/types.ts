export type FeatureStatus =
  | 'NOT_APPROVED'
  | 'CHANGED'
  | 'APPROVED'
  | 'VERIFIED'
  | 'IMPLEMENTATION_DRIFT';

export type JobStatus =
  | 'QUEUED'
  | 'RUNNING'
  | 'DONE'
  | 'FAILED'
  | 'CANCELLED'
  | 'AUTH_REQUIRED';

export type JobType = 'draft' | 'implement' | 'run';

export interface Scenario {
  id: string;
  name: string;
  tags?: string[];
  stepsCount: number;
}

export interface MissingSteps {
  count: number;
  missing: string[];
}

export interface FeatureItem {
  id: string;
  title: string;
  area?: string;
  status: FeatureStatus;
  content?: string;
  fixme?: boolean;
  tags?: string[];
  scenarios?: string[];
  missingSteps?: MissingSteps;
  hasLanguageEs?: boolean;
  lastRun?: {
    status: 'PASSED' | 'FAILED';
    durationMs: number;
    timestamp: string;
  };
}

export interface Job {
  id: string;
  type: JobType;
  status: JobStatus;
  createdAt: string;
  finishedAt?: string;
  payload: {
    feature?: string;
    scenario?: string;
    area?: string;
    all?: boolean;
    where?: string;
    what?: string;
    expect?: string;
  };
  logs?: string[];
}

export interface GuardrailIssue {
  level: 'CRITICAL' | 'WARNING' | 'INFO';
  rule: string;
  message: string;
  file: string;
  line: number;
  snippet?: string;
  remedy?: string;
}

export interface MetaInfo {
  app: string;
  version: string;
  agent: string;
  agentStatus: {
    available: boolean;
    warning?: string;
    version?: string;
  };
  auth: {
    exists: boolean;
    user?: string;
    expiresAt?: string;
    path: string;
  };
  areas: string[];
  stats: {
    totalFeatures: number;
    verified: number;
    approved: number;
    pendingApproval: number;
    withDrift: number;
  };
}
