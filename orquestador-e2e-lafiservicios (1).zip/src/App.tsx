import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  api,
  subscribeToJobStream
} from './services/api';
import {
  FeatureItem,
  FeatureStatus,
  GuardrailIssue,
  Job,
  JobStatus,
  MetaInfo,
  MissingSteps
} from './types';
import { TopBar } from './components/TopBar';
import { FeaturesRail } from './components/FeaturesRail';
import { TrackStepper } from './components/TrackStepper';
import { GherkinEditor } from './components/GherkinEditor';
import { ActionsBar } from './components/ActionsBar';
import { BottomDock } from './components/BottomDock';
import { NewTestForm } from './components/NewTestForm';
import { ReportModal } from './components/ReportModal';
import {
  FileText,
  AlertTriangle,
  X,
  FileCode,
  Tag,
  CheckCircle2,
  Clock,
  Sparkles
} from 'lucide-react';

const MAX_LOG_LINES = 5000;
const FINAL_STATUSES: JobStatus[] = ['DONE', 'FAILED', 'CANCELLED', 'AUTH_REQUIRED'];

// Throttled log hook: accumulates streamed lines and flushes every 100ms
function useThrottledLog() {
  const buf = useRef<string[]>([]);
  const [lines, setLines] = useState<string[]>([]);

  useEffect(() => {
    const t = setInterval(() => {
      if (!buf.current.length) return;
      const batch = buf.current;
      buf.current = [];
      setLines((prev) => {
        const next = prev.concat(batch);
        return next.length > MAX_LOG_LINES ? next.slice(-MAX_LOG_LINES) : next;
      });
    }, 100);
    return () => clearInterval(t);
  }, []);

  const push = useCallback((text: string) => {
    buf.current.push(text);
  }, []);

  const reset = useCallback(() => {
    buf.current = [];
    setLines([]);
  }, []);

  return { lines, push, reset };
}

export default function App() {
  const [meta, setMeta] = useState<MetaInfo | null>(null);
  const [features, setFeatures] = useState<FeatureItem[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [guards, setGuards] = useState<GuardrailIssue[]>([]);
  const [missing, setMissing] = useState<MissingSteps | null>(null);

  // Filters
  const [filterText, setFilterText] = useState('');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [selectedArea, setSelectedArea] = useState('ALL');

  // Work area state
  const [mode, setMode] = useState<'feature' | 'new'>('feature');
  const [sel, setSel] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [saved, setSaved] = useState('');
  const [status, setStatus] = useState<FeatureStatus>('NOT_APPROVED');
  const [scenarios, setScenarios] = useState<string[]>([]);
  const [target, setTarget] = useState('');
  const [diff, setDiff] = useState('');
  const [err, setErr] = useState('');

  // Execution dock state
  const [job, setJob] = useState<{ id: string; status: JobStatus } | null>(null);
  const [dock, setDock] = useState<'consola' | 'historial' | 'guards' | 'diff'>('consola');
  const [mine, setMine] = useState(false);

  // Modal & Theme
  const [reportOpen, setReportOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(() => {
    return (
      localStorage.getItem('lafise_qa_theme') === 'dark' ||
      window.matchMedia('(prefers-color-scheme: dark)').matches
    );
  });

  const log = useThrottledLog();
  const streamUnsub = useRef<(() => void) | null>(null);
  const selRef = useRef<string | null>(null);
  const draftRef = useRef<{ id: string; before: Set<string> } | null>(null);

  // Sync dark mode class with root html
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('lafise_qa_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('lafise_qa_theme', 'light');
    }
  }, [darkMode]);

  const refresh = useCallback(async () => {
    try {
      const [m, f, j, g] = await Promise.all([
        api<MetaInfo>('/meta'),
        api<FeatureItem[]>('/features'),
        api<Job[]>('/jobs'),
        api<{ issues: GuardrailIssue[] }>('/guards'),
      ]);
      setMeta(m);
      setFeatures(f);
      setJobs(j);
      setGuards(g.issues || []);

      // If no feature is selected yet or selected feature is not in the list, pick the first one
      const currentValid = f.some((item) => item.id === selRef.current);
      if ((!selRef.current || !currentValid) && f.length > 0) {
        open(f[0].id);
      }
    } catch (e: any) {
      setErr(e.message || 'Error al conectar con el backend');
    }
  }, []);

  const open = useCallback(async (id: string) => {
    try {
      const f = await api<FeatureItem>('/feature?id=' + encodeURIComponent(id));
      selRef.current = id;
      setSel(id);
      setText(f.content || '');
      setSaved(f.content || '');
      setStatus(f.status);
      setScenarios(f.scenarios || []);
      setMissing(f.missingSteps || null);
      setTarget('');
      setDiff('');
      setMode('feature');
    } catch (e: any) {
      setErr(e.message);
      // Fallback to first available feature if current failed
      const fresh = await api<FeatureItem[]>('/features').catch(() => []);
      if (fresh.length > 0 && fresh[0].id !== id) {
        open(fresh[0].id);
      }
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const guardAction = (fn: (...args: any[]) => Promise<any>) => async (...args: any[]) => {
    setErr('');
    try {
      await fn(...args);
    } catch (e: any) {
      setErr(e.message || 'Ocurrió un error inesperado');
    }
  };

  const watch = guardAction(async (id: string, known?: JobStatus) => {
    streamUnsub.current?.();
    log.reset();
    setDock('consola');
    setJob({ id, status: known ?? 'QUEUED' });

    if (known && FINAL_STATUSES.includes(known)) {
      const r = await api<{ text: string }>(`/jobs/${id}/log`);
      r.text
        .replace(/\n$/, '')
        .split('\n')
        .forEach((l) => log.push(l));
      return;
    }

    const unsub = subscribeToJobStream(id, async (ev) => {
      if (ev.t === 'log' && ev.text) {
        log.push(ev.text);
      }
      if (ev.t === 'warnings' && ev.warnings) {
        setGuards(ev.warnings);
      }
      if (ev.status) {
        setJob({ id, status: ev.status as JobStatus });
      }

      if (ev.status && FINAL_STATUSES.includes(ev.status as JobStatus)) {
        unsub();
        await refresh();
        const d = draftRef.current;
        if (d?.id === id) {
          draftRef.current = null;
          const fresh = await api<FeatureItem[]>('/features');
          const n = fresh.find((x) => !d.before.has(x.id));
          if (n) return open(n.id);
        }
        if (selRef.current) open(selRef.current);
      }
    });

    streamUnsub.current = unsub;
  });

  const start = guardAction(async (type: Job['type'], body: any = {}) => {
    const j = await api<Job>('/jobs', { method: 'POST', body: { type, ...body } });
    if (type === 'draft') {
      draftRef.current = { id: j.id, before: new Set(features.map((f) => f.id)) };
    }
    watch(j.id);
    refresh();
  });

  const save = guardAction(async () => {
    if (!sel) return;
    const r = await api<FeatureItem>('/feature', { method: 'PUT', body: { id: sel, content: text } });
    setSaved(text);
    setStatus(r.status);
    open(sel);
    refresh();
  });

  const approve = guardAction(async () => {
    if (!sel) return;
    const r = await api<FeatureItem>('/approve', { method: 'POST', body: { id: sel } });
    setStatus(r.status);
    open(sel);
    refresh();
  });

  const showDiff = guardAction(async () => {
    const r = await api<{ text: string }>('/diff');
    setDiff(r.text);
    setDock('diff');
  });

  const changeAgent = guardAction(async (agentName: string) => {
    await api('/config', { method: 'POST', body: { agent: agentName } });
    refresh();
  });

  const addLanguageHeader = () => {
    setText((prev) => `# language: es\n${prev.replace(/^\s*#\s*language:\s*[^\n]+\n?/, '')}`);
  };

  const isDirty = text !== saved;
  const isBusy = !!job && !FINAL_STATUSES.includes(job.status);
  const isReady = ['APPROVED', 'VERIFIED'].includes(status);
  const hasSteps = jobs.some(
    (j) => j.type === 'implement' && j.status === 'DONE' && j.payload?.feature === sel
  );
  const currentFeature = features.find((f) => f.id === sel) || null;
  const historyList = jobs.filter(
    (j) => !mine || !sel || j.payload?.feature === sel || j.payload?.all
  );
  const noMissingSteps = missing ? missing.count === 0 : false;

  return (
    <div className="h-full flex flex-col bg-slate-100 text-slate-900 dark:bg-slate-950 dark:text-slate-100 transition-colors">
      {/* Top Bar Header */}
      <TopBar
        meta={meta}
        busy={isBusy}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onChangeAgent={changeAgent}
        onRunSuite={() => start('run', { all: true })}
        guardrailsCount={guards.length}
      />

      {/* Global Alert Strip for Errors */}
      {err && (
        <div className="flex items-center justify-between gap-3 px-4 py-2 bg-rose-50 border-b border-rose-200 text-rose-800 dark:bg-rose-950/80 dark:border-rose-900 dark:text-rose-200 text-xs shrink-0">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-rose-600 dark:text-rose-400 shrink-0" />
            <span className="font-medium">{err}</span>
          </div>
          <button
            onClick={() => setErr('')}
            className="p-1 rounded hover:bg-rose-200/50 dark:hover:bg-rose-900/50"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* Agent Warning Strip if any */}
      {meta?.agentStatus?.warning && meta?.agent !== 'fake' && (
        <div className="flex items-center justify-between gap-3 px-4 py-2 bg-amber-50 border-b border-amber-200 text-amber-800 dark:bg-amber-950/80 dark:border-amber-900 dark:text-amber-200 text-xs shrink-0">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0" />
            <span>{meta.agentStatus.warning}</span>
          </div>
          <button
            onClick={() => changeAgent('fake')}
            className="font-semibold underline hover:text-amber-950 dark:hover:text-amber-100"
          >
            Usar motor Local simulado
          </button>
        </div>
      )}

      {/* Main App Body: Sidebar + Stage */}
      <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
        {/* Left Rail: Features List */}
        <FeaturesRail
          features={features}
          selectedId={sel}
          mode={mode}
          onSelectFeature={(id) => open(id)}
          onOpenNew={() => setMode('new')}
          filterText={filterText}
          onFilterTextChange={setFilterText}
          filterStatus={filterStatus}
          onFilterStatusChange={setFilterStatus}
          selectedArea={selectedArea}
          onSelectArea={setSelectedArea}
          areas={meta?.areas || []}
          busy={isBusy}
          onRunSuite={() => start('run', { all: true })}
        />

        {/* Center / Right: Stage and Bottom Dock */}
        <div className="flex-1 flex flex-col min-h-0 min-w-0 overflow-hidden">
          {/* Work Area Stage */}
          <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 bg-slate-50 dark:bg-slate-950">
            {mode === 'new' ? (
              <NewTestForm
                areas={meta?.areas || []}
                busy={isBusy}
                onSubmit={(data) => start('draft', data)}
                onCancel={() => {
                  if (features.length > 0 && sel) setMode('feature');
                }}
              />
            ) : sel && currentFeature ? (
              <div className="space-y-4 max-w-6xl mx-auto">
                {/* Feature Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
                  <div>
                    <div className="flex items-center gap-2.5">
                      <h1 className="text-lg md:text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
                        {currentFeature.title}
                      </h1>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-mono bg-slate-200/60 dark:bg-slate-800 px-1.5 py-0.5 rounded text-[11px]">
                        features/{currentFeature.id}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>Área: <strong>{currentFeature.area || currentFeature.id.split('/')[0]}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>{scenarios.length} {scenarios.length === 1 ? 'escenario' : 'escenarios'}</span>
                    </div>
                  </div>

                  {/* Actions Bar Shortcut */}
                  <div className="flex items-center gap-2">
                    {currentFeature.tags?.map((t) => (
                      <span
                        key={t}
                        className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-slate-200/70 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                {/* 4-Stage Stepper Track */}
                <TrackStepper status={status} hasSteps={hasSteps} />

                {/* Gherkin Code Editor */}
                <GherkinEditor
                  value={text}
                  savedValue={saved}
                  onChange={setText}
                  onAddLanguageHeader={addLanguageHeader}
                  missingSteps={missing}
                  status={status}
                />

                {/* Actions Bar */}
                <ActionsBar
                  dirty={isDirty}
                  ready={isReady}
                  busy={isBusy}
                  noMissingSteps={noMissingSteps}
                  scenarios={scenarios}
                  targetScenario={target}
                  onTargetScenarioChange={setTarget}
                  onSave={save}
                  onApprove={approve}
                  onImplementSteps={() => start('implement', { feature: sel })}
                  onRunTest={() =>
                    start('run', {
                      feature: sel,
                      ...(target ? { scenario: target } : {})
                    })
                  }
                  onShowDiff={showDiff}
                  onOpenReport={() => setReportOpen(true)}
                />
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-12 text-center text-slate-400">
                <FileCode className="h-12 w-12 text-slate-300 dark:text-slate-600 mb-3" />
                <h3 className="text-base font-semibold text-slate-700 dark:text-slate-300">
                  Ninguna característica seleccionada
                </h3>
                <p className="mt-1 text-xs text-slate-500 max-w-sm">
                  Selecciona una prueba en la barra lateral izquierda o pulsa &quot;Nueva Prueba&quot; para crear una especificación BDD.
                </p>
              </div>
            )}
          </main>

          {/* Bottom Dock: Live Console, History, Guardrails, Diff */}
          <BottomDock
            dockTab={dock}
            onTabChange={setDock}
            lines={log.lines}
            onClearLogs={log.reset}
            job={job}
            busy={isBusy}
            onCancelJob={guardAction(async () => {
              if (job) await api('/jobs/' + job.id, { method: 'DELETE' });
            })}
            history={historyList}
            guards={guards}
            diffText={diff}
            mineOnly={mine}
            onToggleMineOnly={setMine}
            selectedFeatureId={sel}
            onWatchJob={watch}
            onRepeatJob={(type, payload) => start(type, payload)}
          />
        </div>
      </div>

      {/* HTML Report Modal */}
      <ReportModal
        isOpen={reportOpen}
        onClose={() => setReportOpen(false)}
        features={features}
        selectedFeature={currentFeature}
      />
    </div>
  );
}
