import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

try {
  localStorage.removeItem('lafise_qa_features');
  localStorage.removeItem('lafise_qa_jobs');
} catch {}

createRoot(document.getElementById('root')!).render(<App />);
